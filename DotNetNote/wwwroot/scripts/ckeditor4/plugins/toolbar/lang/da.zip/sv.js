/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'sv', {
	toolbarCollapse: 'Dölj verktygsfält',
	toolbarExpand: 'Visa verktygsfält',
	toolbarGroups: {
		document: 'Dokument',
		clipboard: 'Urklipp/ångra',
		editing: 'Redigering',
		forms: 'Formulär',
		basicstyles: 'Basstilar',
		paragraph: 'Paragraf',
		links: 'Länkar',
		insert: 'Infoga',
		styles: 'Stilar',
		colors: 'Färger',
		tools: 'Verktyg'
	},
	toolbars: 'Editorns verktygsfält'
} );
