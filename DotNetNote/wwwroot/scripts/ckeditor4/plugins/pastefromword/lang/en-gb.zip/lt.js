/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'lt', {
	confirmCleanup: 'Tekstas, kurį įkeliate yra kopijuojamas iš Word. Ar norite jį išvalyti prieš įkeliant?',
	error: 'Dėl vidinių sutrikimų, nepavyko išvalyti įkeliamo teksto',
	title: 'Įdėti iš Word',
	toolbar: 'Įdėti iš Word'
} );
