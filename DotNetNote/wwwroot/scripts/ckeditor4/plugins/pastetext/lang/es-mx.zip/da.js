/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'da', {
	button: 'Indsæt som ikke-formateret tekst',
	pasteNotification: 'Klik %1 for at indsætte. Din browser understøtter ikke indsæt med tastatur eller kontekstmenu-valg.',
	title: 'Indsæt som ikke-formateret tekst'
} );
