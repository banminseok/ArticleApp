/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'sr-latn', {
	button: 'Zalepi kao neformiran tekst',
	pasteNotification: 'Pritisnite taster % 1 da bi ste nalepili. Pretraživač ne podržava lepljenje pomoću tastera na traci sa alatkama ili iz menija.',
	title: 'Zalepi kao neformiran tekst'
} );
