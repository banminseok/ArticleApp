/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'pt-br', {
	button: 'Colar como Texto sem Formatação',
	pasteNotification: 'Pressione %1 para colar. Seu navegador não suporta colar a partir do botão da barra de ferramentas ou do menu de contexto.',
	title: 'Colar como Texto sem Formatação'
} );
