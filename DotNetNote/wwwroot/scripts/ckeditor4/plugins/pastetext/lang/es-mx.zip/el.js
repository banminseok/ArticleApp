/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'el', {
	button: 'Επικόλληση ως απλό κείμενο',
	pasteNotification: 'Πατήστε %1 για επικόλληση. Ο φυλλομετρητής σας δεν υποστηρίζει επικόλληση με το κουμπί της γραμμής εργαλείων ή την επιλογή από το μενού δεξιού κλικ.',
	title: 'Επικόλληση ως απλό κείμενο'
} );
