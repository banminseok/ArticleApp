/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'oc', {
	label: 'Format',
	panelTitle: 'Format de paragraf',
	tag_address: 'Adreça',
	tag_div: 'Division (DIV)',
	tag_h1: 'Títol 1',
	tag_h2: 'Títol 2',
	tag_h3: 'Títol 3',
	tag_h4: 'Títol 4',
	tag_h5: 'Títol 5',
	tag_h6: 'Títol 6',
	tag_p: 'Normal',
	tag_pre: 'Preformatat'
} );
