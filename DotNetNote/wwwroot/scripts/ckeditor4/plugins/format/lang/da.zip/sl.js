/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'sl', {
	label: 'Oblika',
	panelTitle: 'Oblika odstavka',
	tag_address: 'Napis',
	tag_div: 'Navaden (DIV)',
	tag_h1: 'Naslov 1',
	tag_h2: 'Naslov 2',
	tag_h3: 'Naslov 3',
	tag_h4: 'Naslov 4',
	tag_h5: 'Naslov 5',
	tag_h6: 'Naslov 6',
	tag_p: 'Navaden',
	tag_pre: 'Oblikovan'
} );
