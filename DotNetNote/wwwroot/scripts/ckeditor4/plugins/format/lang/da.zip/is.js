/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'is', {
	label: 'Stílsnið',
	panelTitle: 'Stílsnið',
	tag_address: 'Vistfang',
	tag_div: 'Venjulegt (DIV)',
	tag_h1: 'Fyrirsögn 1',
	tag_h2: 'Fyrirsögn 2',
	tag_h3: 'Fyrirsögn 3',
	tag_h4: 'Fyrirsögn 4',
	tag_h5: 'Fyrirsögn 5',
	tag_h6: 'Fyrirsögn 6',
	tag_p: 'Venjulegt letur',
	tag_pre: 'Forsniðið'
} );
