/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'pl', {
	label: 'Format',
	panelTitle: 'Format',
	tag_address: 'Adres',
	tag_div: 'Normalny (DIV)',
	tag_h1: 'Nagłówek 1',
	tag_h2: 'Nagłówek 2',
	tag_h3: 'Nagłówek 3',
	tag_h4: 'Nagłówek 4',
	tag_h5: 'Nagłówek 5',
	tag_h6: 'Nagłówek 6',
	tag_p: 'Normalny',
	tag_pre: 'Tekst sformatowany'
} );
