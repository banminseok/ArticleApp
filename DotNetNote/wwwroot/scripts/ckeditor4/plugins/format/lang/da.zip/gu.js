/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'gu', {
	label: 'ફૉન્ટ ફૉર્મટ, રચનાની શૈલી',
	panelTitle: 'ફૉન્ટ ફૉર્મટ, રચનાની શૈલી',
	tag_address: 'સરનામું',
	tag_div: 'શીર્ષક (DIV)',
	tag_h1: 'શીર્ષક 1',
	tag_h2: 'શીર્ષક 2',
	tag_h3: 'શીર્ષક 3',
	tag_h4: 'શીર્ષક 4',
	tag_h5: 'શીર્ષક 5',
	tag_h6: 'શીર્ષક 6',
	tag_p: 'સામાન્ય',
	tag_pre: 'ફૉર્મટેડ'
} );
