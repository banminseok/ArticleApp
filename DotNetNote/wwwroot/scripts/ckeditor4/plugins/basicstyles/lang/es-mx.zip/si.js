/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'si', {
	bold: 'තද අකුරින් ලියනලද',
	italic: 'බැධීඅකුරින් ලියන ලද',
	strike: 'Strikethrough', // MISSING
	subscript: 'Subscript', // MISSING
	superscript: 'Superscript', // MISSING
	underline: 'යටින් ඉරි අදින ලද'
} );
