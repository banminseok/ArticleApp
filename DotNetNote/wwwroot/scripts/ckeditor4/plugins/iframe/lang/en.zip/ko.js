/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'ko', {
	border: '프레임 테두리 표시',
	noUrl: '아이프레임 주소(URL)를 입력해주세요.',
	scrolling: '스크롤바 사용',
	title: '아이프레임 속성',
	toolbar: '아이프레임',
	tabindex: 'Remove from tabindex' // MISSING
} );
