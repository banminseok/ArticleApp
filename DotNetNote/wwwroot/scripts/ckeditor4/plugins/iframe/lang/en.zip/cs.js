/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'cs', {
	border: 'Zobrazit okraj',
	noUrl: 'Zadejte prosím URL obsahu pro IFrame',
	scrolling: 'Zapnout posuvníky',
	title: 'Vlastnosti IFrame',
	toolbar: 'IFrame',
	tabindex: 'Odstranit ze zaměření tabulátorem.'
} );
