/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'hr', {
	border: 'Prikaži okvir IFrame-a',
	noUrl: 'Unesite URL IFrame-a',
	scrolling: 'Omogući trake za skrolanje',
	title: 'IFrame svojstva',
	toolbar: 'IFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
