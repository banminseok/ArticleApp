/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'ca', {
	border: 'Mostra la vora del marc',
	noUrl: 'Si us plau, introdueixi la URL de l\'iframe',
	scrolling: 'Activa les barres de desplaçament',
	title: 'Propietats de l\'IFrame',
	toolbar: 'IFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
