/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'hu', {
	border: 'Legyen keret',
	noUrl: 'Kérem írja be a iframe URL-t',
	scrolling: 'Gördítősáv bekapcsolása',
	title: 'IFrame Tulajdonságok',
	toolbar: 'IFrame',
	tabindex: 'Eltávolítás a tabindexből'
} );
