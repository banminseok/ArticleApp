/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'fo', {
	border: 'Vís frame kant',
	noUrl: 'Vinarliga skriva URL til iframe',
	scrolling: 'Loyv scrollbars',
	title: 'Møguleikar fyri IFrame',
	toolbar: 'IFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
