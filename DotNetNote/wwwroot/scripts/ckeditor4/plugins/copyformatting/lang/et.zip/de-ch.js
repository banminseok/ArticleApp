/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'copyformatting', 'de-ch', {
	label: 'Formatierung kopieren',
	notification: {
		copied: 'Formatierung kopiert',
		applied: 'Formatierung angewendet',
		canceled: 'Formatierung abgebrochen',
		failed: 'Formatierung fehlgeschlagen. Sie können Stile nicht anwenden, ohne sie zuerst zu kopieren.'
	}
} );
