/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'da', {
	copy: 'Copyright &copy; $1. Alle rettigheder forbeholdes.',
	dlgTitle: 'Om CKEditor 4',
	moreInfo: 'For informationer omkring licens, se venligst vores hjemmeside (på engelsk):'
} );
