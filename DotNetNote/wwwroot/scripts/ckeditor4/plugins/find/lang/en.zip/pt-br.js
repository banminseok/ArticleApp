/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'find', 'pt-br', {
	find: 'Localizar',
	findOptions: 'Opções',
	findWhat: 'Procurar por:',
	matchCase: 'Coincidir Maiúsculas/Minúsculas',
	matchCyclic: 'Coincidir cíclico',
	matchWord: 'Coincidir a palavra inteira',
	notFoundMsg: 'O texto especificado não foi encontrado.',
	replace: 'Substituir',
	replaceAll: 'Substituir Tudo',
	replaceSuccessMsg: '%1 ocorrência(s) substituída(s).',
	replaceWith: 'Substituir por:',
	title: 'Localizar e Substituir'
} );
