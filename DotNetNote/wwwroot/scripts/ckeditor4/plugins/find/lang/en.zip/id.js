/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'find', 'id', {
	find: 'Temukan',
	findOptions: 'Opsi menemukan',
	findWhat: 'Temukan apa:',
	matchCase: 'Match case', // MISSING
	matchCyclic: 'Match cyclic', // MISSING
	matchWord: 'Match whole word', // MISSING
	notFoundMsg: 'Teks yang dipilih tidak ditemukan',
	replace: 'Ganti',
	replaceAll: 'Ganti Semua',
	replaceSuccessMsg: '%1 occurrence(s) replaced.', // MISSING
	replaceWith: 'Ganti dengan:',
	title: 'Temukan dan Ganti'
} );
