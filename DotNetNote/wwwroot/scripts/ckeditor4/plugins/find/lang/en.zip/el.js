/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'find', 'el', {
	find: 'Εύρεση',
	findOptions: 'Επιλογές Εύρεσης',
	findWhat: 'Εύρεση για:',
	matchCase: 'Ταίριασμα πεζών/κεφαλαίων',
	matchCyclic: 'Αναδρομική εύρεση',
	matchWord: 'Εύρεση μόνο πλήρων λέξεων',
	notFoundMsg: 'Το κείμενο δεν βρέθηκε.',
	replace: 'Αντικατάσταση',
	replaceAll: 'Αντικατάσταση Όλων',
	replaceSuccessMsg: 'Ο(ι) όρος(-οι) αντικαταστήθηκε(-αν) %1 φορές.',
	replaceWith: 'Αντικατάσταση με:',
	title: 'Εύρεση και Αντικατάσταση'
} );
