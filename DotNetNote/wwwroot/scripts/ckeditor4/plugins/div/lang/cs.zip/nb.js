/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'nb', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Tittel',
	cssClassInputLabel: 'Stilark-klasser',
	edit: 'Rediger Div',
	inlineStyleInputLabel: 'Inlinestiler',
	langDirLTRLabel: 'Venstre til høyre (LTR)',
	langDirLabel: 'Språkretning',
	langDirRTLLabel: 'Høyre til venstre (RTL)',
	languageCodeInputLabel: ' Språkkode',
	remove: 'Fjern Div',
	styleSelectLabel: 'Stil',
	title: 'Sett inn Div Container',
	toolbar: 'Sett inn Div Container'
} );
