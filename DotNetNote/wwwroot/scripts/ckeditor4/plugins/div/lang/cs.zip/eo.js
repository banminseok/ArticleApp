/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'eo', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Priskriba Titolo',
	cssClassInputLabel: 'Stilfolioklasoj',
	edit: 'Redakti Div',
	inlineStyleInputLabel: 'Enlinia stilo',
	langDirLTRLabel: 'Maldekstre dekstren (angle LTR)',
	langDirLabel: 'Skribdirekto',
	langDirRTLLabel: 'Dekstre maldekstren (angle RTL)',
	languageCodeInputLabel: ' Lingvokodo',
	remove: 'Forigi Div',
	styleSelectLabel: 'Stilo',
	title: 'Krei DIV ujon',
	toolbar: 'Krei DIV ujon'
} );
