/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'cs', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Nápovědní titulek',
	cssClassInputLabel: 'Třídy stylů',
	edit: 'Změnit Div',
	inlineStyleInputLabel: 'Vnitřní styly',
	langDirLTRLabel: 'Zleva doprava (LTR)',
	langDirLabel: 'Směr jazyka',
	langDirRTLLabel: 'Zprava doleva (RTL)',
	languageCodeInputLabel: ' Kód jazyka',
	remove: 'Odstranit Div',
	styleSelectLabel: 'Styly',
	title: 'Vytvořit Div kontejner',
	toolbar: 'Vytvořit Div kontejner'
} );
