/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'id', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Penasehat Judul',
	cssClassInputLabel: 'Kelas Stylesheet',
	edit: 'Sunting Div',
	inlineStyleInputLabel: 'Inline Style', // MISSING
	langDirLTRLabel: 'Kiri ke Kanan (LTR)',
	langDirLabel: 'Arah Bahasa',
	langDirRTLLabel: 'Kanan ke Kiri (RTL)',
	languageCodeInputLabel: 'Kode Bahasa',
	remove: 'Hapus Div',
	styleSelectLabel: 'Gaya',
	title: 'Ciptakan Wadah Div',
	toolbar: 'Cipatakan Wadah Div'
} );
