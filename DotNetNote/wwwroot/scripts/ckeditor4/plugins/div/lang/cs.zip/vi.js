/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'vi', {
	IdInputLabel: 'Định danh (id)',
	advisoryTitleInputLabel: 'Nhan đề hướng dẫn',
	cssClassInputLabel: 'Các lớp CSS',
	edit: 'Chỉnh sửa',
	inlineStyleInputLabel: 'Kiểu nội dòng',
	langDirLTRLabel: 'Trái sang phải (LTR)',
	langDirLabel: 'Hướng ngôn ngữ',
	langDirRTLLabel: 'Phải qua trái (RTL)',
	languageCodeInputLabel: 'Mã ngôn ngữ',
	remove: 'Xóa bỏ',
	styleSelectLabel: 'Kiểu (style)',
	title: 'Tạo khối các thành phần',
	toolbar: 'Tạo khối các thành phần'
} );
