/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'el', {
	button: 'Πρότυπα',
	emptyListMsg: '(Δεν έχουν καθοριστεί πρότυπα)',
	insertOption: 'Αντικατάσταση υπάρχοντων περιεχομένων',
	options: 'Επιλογές Προτύπου',
	selectPromptMsg: 'Παρακαλώ επιλέξτε πρότυπο για εισαγωγή στο πρόγραμμα',
	title: 'Πρότυπα Περιεχομένου'
} );
