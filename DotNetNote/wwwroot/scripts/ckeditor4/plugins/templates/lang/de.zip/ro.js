/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'ro', {
	button: 'Template-uri (şabloane)',
	emptyListMsg: '(Niciun template (şablon) definit)',
	insertOption: 'Înlocuieşte cuprinsul actual',
	options: 'Opțiuni șabloane',
	selectPromptMsg: 'Vă rugăm selectaţi template-ul (şablonul) ce se va deschide în editor<br>(conţinutul actual va fi pierdut):',
	title: 'Template-uri (şabloane) de conţinut'
} );
