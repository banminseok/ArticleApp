/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'km', {
	button: 'ពុម្ព​គំរូ',
	emptyListMsg: '(មិន​មាន​ពុម្ព​គំរូ​ត្រូវ​បាន​កំណត់)',
	insertOption: 'ជំនួស​ក្នុង​មាតិកា​បច្ចុប្បន្ន',
	options: 'ជម្រើស​ពុម្ព​គំរូ',
	selectPromptMsg: 'សូម​រើស​ពុម្ព​គំរូ​ដើម្បី​បើក​ក្នុង​កម្មវិធី​សរសេរ​អត្ថបទ',
	title: 'ពុម្ព​គំរូ​មាតិកា'
} );
